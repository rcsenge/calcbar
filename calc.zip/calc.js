var calcBar = $('#calc'); //for html
var value = []; //string that gets turned into float
const $errorMessage = $(".error-message");

$('div.container button').css({ 'width': '100px', 'height': '50px'});
function changeColor() {
    $('ul.showList').toggle();
}
function resetColors() {
    $('body').css('background-color', ''); 
    $('.container').css('background', 'white');
    $('button:not(i), .items').css('background-color', ''); 
    $('.items').css('box-shadow', '');
    $('#calc').css('color', ''); 
    $('.container').css('border', ''); 
    $('.container').css('box-shadow', ''); 
    $('.error-message').css('color', '');
}


function colorPink(){
    resetColors();
    $('button:not(.paint-brush, i), .items').css('background-color', '#eea3de')
}
function colorPurple(){
    resetColors();
    $('button:not(.paint-brush, i), .items').css('background-color', 'rgb(183, 140, 224)')
}
function colorBlue(){
    resetColors();
    $('button:not(.paint-brush, i), .items').css('background-color', 'rgb(72, 166, 206)')
}
function colorGreen(){
    resetColors();
    $('button:not(.paint-brush, i), .items').css('background-color', 'rgb(106, 166, 128)')
}
function colorDark(){
    $('body').css('background-color', 'rgb(0, 0, 0');
    $('.container').css('background-color', 'black');
    $('button:not(i), .items').css('background-color', 'black');
    $('.items').css('box-shadow', 'rgb(125, 9, 205) 3px 4px 20px 0px');
    $('#calc').css('color', '#FFFFFF');
    $('.container').css('border', '2px solid white');
    $('.container').css('box-shadow', 'rgb(125 9 205) 0px 0px 20px 5px');
    $('.error-message').css('color', '#FFFFFF');
}


function displayNumber(a) {
    value.push(a.toString());
    calcBar.text(value.join(''));
}

function add(b){
    value.push('+');
    value.push(b.toString()); 
    calcBar.text(value.join(''));
}

function substract(b){
    value.push('-');
    value.push(b.toString());
    calcBar.text(value.join(''));
}

function multiply(b){
    value.push('*');
    value.push(b.toString());
    calcBar.text(value.join(''));
}

function decimal(b){
    value.push('.');
    value.push(b.toString());
    calcBar.text(value.join(''));
}

function divide(b){
    value.push('/');
    value.push(b.toString());
    calcBar.text(value.join(''));
}

function deleteNumber(){
    value.pop(); 
}

function clearAll() {
    value = [];
    calcBar.text('');
}

function equals() {
    var result = eval(value.join(''))
    if (result === Infinity){
        $errorMessage.text("Error: Division by zero");
        $errorMessage.show();
        value = [];
        return; 
    }
    parseFloat(result)
    calcBar.text(result);
}
